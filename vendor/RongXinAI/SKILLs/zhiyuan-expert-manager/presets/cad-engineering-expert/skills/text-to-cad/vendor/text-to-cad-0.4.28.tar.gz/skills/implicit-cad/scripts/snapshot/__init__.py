"""Implicit CAD snapshot CLI."""

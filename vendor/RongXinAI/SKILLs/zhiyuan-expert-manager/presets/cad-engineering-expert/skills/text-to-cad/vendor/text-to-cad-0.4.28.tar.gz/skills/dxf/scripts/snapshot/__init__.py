"""DXF drawing snapshot CLI."""
